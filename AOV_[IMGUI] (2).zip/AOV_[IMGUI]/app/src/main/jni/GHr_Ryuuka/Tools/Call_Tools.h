#pragma once

#include "curl/json.hpp"
#include "Tools.h"
#include "Jni_Stuff.h"
#include "ImGuiStuff.h"
#include "ESP.h"

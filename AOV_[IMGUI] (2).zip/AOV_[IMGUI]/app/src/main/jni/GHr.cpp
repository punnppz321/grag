#include "Includes/obfuscate.h"
#include "GHr_Ryuuka/Call_Me.h"

EGLBoolean (*orig_eglSwapBuffers)(EGLDisplay dpy, EGLSurface surface);
EGLBoolean _eglSwapBuffers(EGLDisplay dpy, EGLSurface surface) {
	
	eglQuerySurface(dpy, surface, EGL_WIDTH, &glWidth);
	eglQuerySurface(dpy, surface, EGL_HEIGHT, &glHeight);
	
	if (glWidth <= 0 || glHeight <= 0) {
		return eglSwapBuffers(dpy, surface);
	}
	
	if (!Config.InitImGui.initImGui) {
		ImGui::CreateContext();
		
		ImGuiStyle* style = &ImGui::GetStyle();
		style->WindowRounding = 5.3f;
        style->FrameRounding = 2.3f;
        style->ScrollbarRounding = 0;
		style->WindowTitleAlign = ImVec2(0.5, 0.5);
        style->WindowMinSize = ImVec2(400, 180);
        style->FramePadding = ImVec2(8, 6);
		style->ScaleAllSizes(1.0f);
        style->ScrollbarSize /= 1;
		
		ImGui_ImplAndroid_Init();
		ImGui_ImplOpenGL3_Init(OBFUSCATE("#version 300 es"));
		ImGui::StyleColorsDark();
		
		ImGuiIO* io = &ImGui::GetIO();
		io->ConfigWindowsMoveFromTitleBarOnly = true;
        io->IniFilename = NULL;
		
		static const ImWchar icons_ranges[] = {0x0020, 0x00FF, 0x3000, 0x30FF, 0x31F0, 0x31FF, 0xFF00, 0xFFEF, 0x4e00, 0x9FAF, 0};
        ImFontConfig icons_config;

        ImFontConfig CustomFont;
        CustomFont.FontDataOwnedByAtlas = false;

        icons_config.MergeMode = true;
        icons_config.PixelSnapH = true;
        icons_config.OversampleH = 2.5;
        icons_config.OversampleV = 2.5;

        io->Fonts->AddFontFromMemoryTTF(const_cast<std::uint8_t*>(Custom), sizeof(Custom), 21.f, &CustomFont);
        io->Fonts->AddFontFromMemoryCompressedTTF(font_awesome_data, font_awesome_size, 19.0f, &icons_config, icons_ranges);
		
		ImFontConfig font_cfg;
		font_cfg.SizePixels = 22.0f;
		io->Fonts->AddFontDefault(&font_cfg);
		
		Config.InitImGui.initImGui = true;
	}
	
	ImGui_ImplOpenGL3_NewFrame();
	ImGui_ImplAndroid_NewFrame(glWidth, glHeight);
	ImGui::NewFrame();
	
	DrawESP(ImGui::GetBackgroundDrawList());
	
	if (ImGui::Begin(OBFUSCATE("AndroidRepublic.org - Garena AOV")), ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoCollapse) {
		
		if (ImGui::BeginTabBar(OBFUSCATE("##tabbar"))) {
				
			if (ImGui::BeginTabItem(OBFUSCATE("Visual - Menu"))) {
				ImGui::BeginGroupPanel(OBFUSCATE("ESP"), ImVec2(0.0f, 0.0f));
				ImGui::BeginGroupPanel(OBFUSCATE("Player ESP"), ImVec2(0.0f, 0.0f));
				
				ImGui::Checkbox(OBFUSCATE("Enable ESP"), &Enable_ESP);
				ImGui::Checkbox(OBFUSCATE("Line"), &PlayerLine);
				ImGui::Checkbox(OBFUSCATE("Box"), &PlayerBox);
				ImGui::Checkbox(OBFUSCATE("Health"), &PlayerHealth);
				ImGui::Checkbox(OBFUSCATE("Name"), &PlayerName);
				ImGui::Checkbox(OBFUSCATE("Distance"), &PlayerDistance);
				ImGui::Checkbox(OBFUSCATE("Alert"), &PlayerAlert);
				
				ImGui::EndGroupPanel();
				ImGui::EndGroupPanel();
				
				ImGui::EndTabItem();
			}
		}
	}
	
	ImGui::End();
    ImGui::Render();
	ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
	return orig_eglSwapBuffers(dpy, surface);
}

void *Init_Thread(void *) {
	
	while (!il2cppMap) {
		il2cppMap = Tools::GetBaseAddress(targetLib);
		sleep(10);
	}
	
	sleep(10);
	
	IL2Cpp::Il2CppAttach();
	
	Config.InitImGui.bInitDone = true;
	
	return nullptr;
}

JNIEXPORT jint JNICALL 
JNI_OnLoad(JavaVM *vm, void * reserved) {
	jvm = vm;
	JNIEnv *env;
	
	vm->GetEnv((void **) &env, JNI_VERSION_1_6);
	
	Tools::Hook((void *) DobbySymbolResolver(OBFUSCATE("/system/lib/libEGL.so"), OBFUSCATE("eglSwapBuffers")), (void *) _eglSwapBuffers, (void **) &orig_eglSwapBuffers);
	Tools::Hook((void *) DobbySymbolResolver(OBFUSCATE("/system/lib/libandroid.so"), OBFUSCATE("ANativeWindow_getWidth")), (void *) _ANativeWindow_getWidth, (void **) &orig_ANativeWindow_getWidth);
	Tools::Hook((void *) DobbySymbolResolver(OBFUSCATE("/system/lib/libandroid.so"), OBFUSCATE("ANativeWindow_getHeight")), (void *) _ANativeWindow_getHeight, (void **) &orig_ANativeWindow_getHeight);
	Tools::Hook((void *) DobbySymbolResolver(OBFUSCATE("/system/lib/libinput.so"), OBFUSCATE("_ZN7android13InputConsumer21initializeMotionEventEPNS_11MotionEventEPKNS_12InputMessageE")), (void *) myInput, (void **) &origInput);
	
	pthread_t myThread;
	pthread_create(&myThread, NULL, Init_Thread, NULL);
	
	return JNI_VERSION_1_6;
}
